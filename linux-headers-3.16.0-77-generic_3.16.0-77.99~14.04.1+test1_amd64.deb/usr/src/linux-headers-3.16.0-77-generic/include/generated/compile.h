/* This file is auto generated, version 99~14.04.1+test1 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#99~14.04.1+test1 SMP Thu Sep 14 19:13:56 UTC 2017"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "guc3-heliosagent-dxia-f55j.guc3.spotify.net"
#define LINUX_COMPILER "gcc version 4.8.4 (Ubuntu 4.8.4-2ubuntu1~14.04.3) "
